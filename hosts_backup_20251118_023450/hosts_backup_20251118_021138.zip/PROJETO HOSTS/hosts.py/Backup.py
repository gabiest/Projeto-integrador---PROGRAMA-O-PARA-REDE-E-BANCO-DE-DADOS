DRIVE_FOLDER_ID = '1IfMK8UGcaT2cUALo5Uas2mB0n9zIp8hs'
import os
import zipfile
import datetime
from google.oauth2.service_account import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# --- CONFIGURAÇÕES ---
# O escopo define o nível de acesso. Drive completo é o mais simples para começar.
SCOPES = ['https://www.googleapis.com/auth/drive']
# O nome do arquivo de credenciais baixado do Google Cloud Console
CREDENTIALS_FILE = 'credentials.json'

# Diretório raiz do seu projeto (assumindo que o script está em PROJETO HOSTS/hosts.py/backup.py)
# Você precisa subir dois níveis para chegar à pasta PROJETO HOSTS
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))

# Nome do arquivo ZIP de backup
BACKUP_FILENAME = f"hosts_backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
BACKUP_PATH = os.path.join(PROJECT_ROOT, BACKUP_FILENAME)

# ID da pasta de destino no Google Drive.
# *** ID DA SUA PASTA: 1IfMK8UGcaT2cUALo5Uas2mB0n9zIp8hs ***
DRIVE_FOLDER_ID = '1IfMK8UGcaT2cUALo5Uas2mB0n9zIp8hs' 

# --- FUNÇÕES ---

def authenticate_google_drive():
    """Realiza a autenticação e retorna o objeto de serviço do Google Drive."""
    creds = None
    # O arquivo token.json armazena os tokens de acesso e de atualização do usuário
    # e é criado automaticamente após a primeira autorização.
    TOKEN_FILE = 'token.json'
    
    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)
    
    # Se não houver credenciais válidas, permite o login.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                CREDENTIALS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        # Salva as credenciais para a próxima execução
        with open(TOKEN_FILE, 'w') as token:
            token.write(creds.to_json())
            
    return build('drive', 'v3', credentials=creds)

def create_zip_backup(root_dir, output_path):
    """Compacta todo o conteúdo do diretório raiz do projeto."""
    print(f"Criando arquivo ZIP de backup em: {output_path}...")
    
    # Lista de arquivos/pastas para ignorar no backup
    EXCLUDE_LIST = [
        '__pycache__', 
        '.git', 
        BACKUP_FILENAME, # Evita incluir o próprio backup no backup
        'token.json', # Não precisa de backup da credencial de acesso
        'credentials.json',
        'meu_banco.db' 
    ]

    try:
        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(root_dir):
                # Modifica 'dirs' no local para excluir pastas
                dirs[:] = [d for d in dirs if d not in EXCLUDE_LIST]
                
                # Cria o caminho relativo dentro do ZIP
                relative_path_start = len(root_dir) + len(os.sep) 

                for file in files:
                    # Ignora arquivos de credenciais ou o próprio script
                    if file in EXCLUDE_LIST:
                        continue

                    full_path = os.path.join(root, file)
                    arcname = full_path[relative_path_start:]

                    # Ignora se o arquivo for o próprio script backup.py
                    if "backup.py" in arcname:
                        continue

                    zipf.write(full_path, arcname)
        print("✅ Backup ZIP criado com sucesso!")
        return True
    except Exception as e:
        print(f"❌ Erro ao criar o arquivo ZIP: {e}")
        return False


def upload_to_drive(service, file_path, folder_id=''):
    """Faz o upload do arquivo para o Google Drive."""
    file_metadata = {
        'name': os.path.basename(file_path),
        'mimeType': 'application/zip'
    }

    if folder_id:
        file_metadata['parents'] = [folder_id]

    media = MediaFileUpload(file_path, mimetype='application/zip')

    print(f"Iniciando upload de '{os.path.basename(file_path)}' para o Google Drive...")
    
    try:
        file = service.files().create(body=file_metadata,
                                      media_body=media,
                                      fields='id').execute()
        print(f"✅ Upload concluído. ID do Arquivo no Drive: {file.get('id')}")
        return True
    except Exception as e:
        print(f"❌ Erro ao fazer upload para o Google Drive: {e}")
        return False


def cleanup(file_path):
    """Remove o arquivo ZIP local."""
    try:
        os.remove(file_path)
        print(f"🗑️ Arquivo local '{os.path.basename(file_path)}' removido.")
    except Exception as e:
        print(f"❌ Erro ao remover o arquivo local: {e}")


# --- EXECUÇÃO PRINCIPAL ---

def run_backup():
    print("Iniciando rotina de Backup para o Google Drive...")
    
    # 1. Compactar o Projeto
    if create_zip_backup(PROJECT_ROOT, BACKUP_PATH):
        
        # 2. Autenticar com o Google Drive
        drive_service = authenticate_google_drive()
        
        # 3. Fazer o Upload
        if upload_to_drive(drive_service, BACKUP_PATH, DRIVE_FOLDER_ID):
            
            # 4. Limpeza Local
            cleanup(BACKUP_PATH)
            
        print("\nProcesso de backup finalizado.")
    else:
        print("\nProcesso de backup falhou na criação do ZIP.")


if __name__ == '__main__':
    run_backup()